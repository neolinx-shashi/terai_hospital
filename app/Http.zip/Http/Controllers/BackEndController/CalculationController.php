<?php

namespace App\Http\Controllers\BackEndController;

use App\Models\Billing;
use App\Models\Patient;
use App\Models\IPatient;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Carbon\Carbon;

class CalculationController extends Controller
{

    private $patient;
    private $iPatient;
    private $billing;

    public function __construct(Patient $patient,
                                Billing $billing,
                                IPatient $iPatient)
    {
        $this->middleware('auth');
        $this->patient = $patient;
        $this->billing = $billing;
        $this->iPatient = $iPatient;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function dailyRevenue()
    {
        $title = "Today's Revenue";
        $today = Carbon::now()->toDateString();
        $now = Carbon::now();

        $patients = $this->iPatient
            ->where('refund_status', 'Active')
            ->where('patient_type', 'OPD')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')
            ->get();

        $ePatients = $this->iPatient
            ->where('patient_type', 'Emergency')
            ->where('status', 'Discharged')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')
            ->get();

        //dd($ePatients);

        $iPatients = $this->iPatient
            ->where('status', 'Discharged')
            ->where('patient_type', 'IPD')
            ->whereDate('discharged_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')
            ->get();

        //dd($iPatients);

        $testPatients = $this->billing
            ->where('status', 'Active')
            //->where('patient_type', 'test')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')
            ->get();

        return view('backendview.calculation.calculation', compact('patients', 'testPatients', 'today', 'title', 'iPatients', 'now', 'ePatients'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function weeklyRevenue()
    {
        $now = Carbon::now();
        $title = "This Week's Revenue";
        $today = Carbon::now()->toDateString();
        //$week = date('w');
        $date = Carbon::parse('last sunday')->startOfDay();

        $patients = $this->iPatient
            ->where('refund_status', 'Active')
            ->where('patient_type', 'OPD')
            //->where('created_at', '=', $week)
            ->where('created_at', '>=', $date)
            ->orderBy('created_at', 'DESC')
            ->get();

        $ePatients = $this->iPatient
            ->where('patient_type', 'Emergency')
            ->where('status', 'Discharged')
            ->where('created_at', '>=', $date)
            ->orderBy('created_at', 'DESC')
            ->get();

        $iPatients = $this->iPatient
            ->where('status', 'Discharged')
            ->where('patient_type', 'IPD')
            ->where('discharged_at', '>=', $date)
            ->orderBy('created_at', 'DESC')
            ->get();

        $testPatients = $this->billing
            ->where('status', 'Active')
            //->where('patient_type', 'test')
            //->whereWeek('created_at', '=', $week)
            ->where('created_at', '>=', $date)
            ->orderBy('created_at', 'DESC')
            ->get();

        return view('backendview.calculation.calculation', compact('patients', 'testPatients', 'today', 'title', 'iPatients', 'ePatients', 'now'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function monthlyRevenue()
    {
        $now = Carbon::now();
        $title = "This Month's Revenue";
        $today = Carbon::now()->toDateString();
        $month = date('m');

        $patients = $this->iPatient
            ->where('refund_status', 'Active')
            ->where('patient_type', 'OPD')
            ->whereMonth('created_at', '=', $month)
            //->where( 'created_at', '>', Carbon::now()->subDays(30))
            ->orderBy('created_at', 'DESC')
            ->get();

        $ePatients = $this->iPatient
            ->where('patient_type', 'Emergency')
            ->where('status', 'Discharged')
            ->whereMonth('created_at', '=', $month)
            ->orderBy('created_at', 'DESC')
            ->get();

        $iPatients = $this->iPatient
            ->where('status', 'Discharged')
            ->where('patient_type', 'IPD')
            ->whereMonth('discharged_at', '=', $month)
            ->orderBy('created_at', 'DESC')
            ->get();

        $testPatients = $this->billing
            ->where('status', 'Active')
            //->where('patient_type', 'test')
            ->whereMonth('created_at', '=', $month)
            //->where( 'created_at', '>', Carbon::now()->subDays(30))
            ->orderBy('created_at', 'DESC')
            ->get();

        return view('backendview.calculation.calculation', compact('patients', 'testPatients', 'today', 'title', 'iPatients', 'ePatients', 'now'));
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function yearlyRevenue()
    {
        $now = Carbon::now();
        $title = "This Year's Revenue";
        $today = Carbon::now()->toDateString();
        $year = date('Y');

        $patients = $this->iPatient
            ->where('refund_status', 'Active')
            ->where('patient_type', 'OPD')
            ->whereYear('created_at', '=', $year)
            //->where('created_at', 'like', '%' . $year . '%')
            ->orderBy('created_at', 'DESC')
            ->get();

        $ePatients = $this->iPatient
            ->where('patient_type', 'Emergency')
            ->where('status', 'Discharged')
            ->whereYear('created_at', '=', $year)
            ->orderBy('created_at', 'DESC')
            ->get();

        //dd($ePatients);

        $iPatients = $this->iPatient
            ->where('status', 'Discharged')
            ->where('patient_type', 'IPD')
            ->whereYear('discharged_at', '=', $year)
            ->orderBy('created_at', 'DESC')
            ->get();

        //dd($iPatients);

        $testPatients = $this->billing
            ->where('status', 'Active')
            //->where('patient_type', 'test')
            ->whereYear('created_at', '=', $year)
            //->where('created_at', 'like', '%' . $year . '%')
            ->orderBy('created_at', 'DESC')
            ->get();
        //dd($testPatients);

        return view('backendview.calculation.calculation', compact('patients', 'testPatients', 'today', 'title', 'iPatients', 'ePatients', 'now'));
    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function revenueByDate(Request $request)
    {
        $now = Carbon::now();
        $today = Carbon::now()->toDateString();
        $input = $request->all();
        $from = $input['date_from'];
        $to = $input['date_to'];
        $time = \Carbon\Carbon::now();
        date_format($time, ' l - jS F, Y');
        $title = "Revenue from $from to $to";
        //dd($time);

        /*$to = strtotime($to);
        $to = strtotime("+1 day", $to);
        $to = date('Y-m-d', $to);*/
        //dd($to);

        if ($from == $to) {
            $patients = $this->iPatient
                ->where('refund_status', 'Active')
                ->where('patient_type', 'OPD')
                ->whereDate('created_at', '=', $from)
                ->orderBy('created_at', 'DESC')
                ->get();

            $iPatients = $this->iPatient
                ->where('status', 'Discharged')
                ->where('patient_type', 'IPD')
                ->whereDate('discharged_at', '=', $from)
                ->orderBy('created_at', 'DESC')
                ->get();

            $ePatients = $this->iPatient
                ->where('patient_type', 'Emergency')
                ->where('status', 'Discharged')
                ->whereDate('discharged_at', '=', $from)
                ->orderBy('created_at', 'DESC')
                ->get();

            $testPatients = $this->billing
                ->where('status', 'Active')
                //->where('patient_type', 'test')
                ->whereDate('date', '=', $from)
                ->orderBy('created_at', 'DESC')
                ->get();
        } else {
            $patients = $this->iPatient
                ->select(DB::raw('patients.*', "DATE_FORMAT(patients.created_at, '%Y/%m/%d') as created_at"))
                ->where('refund_status', 'Active')
                ->where('patient_type', 'OPD')
                ->whereBetween('created_at', [$from, $to])
                ->orderBy('created_at', 'DESC')
                ->get();

            $iPatients = $this->iPatient
                ->where('status', 'Discharged')
                ->where('patient_type', 'IPD')
                ->whereBetween('created_at', [$from, $to])
                ->orderBy('created_at', 'DESC')
                ->get();

            $ePatients = $this->iPatient
                ->where('patient_type', 'Emergency')
                ->where('status', 'Discharged')
                ->whereBetween('created_at', [$from, $to])
                ->orderBy('created_at', 'DESC')
                ->get();

            $testPatients = $this->billing
                ->where('status', 'Active')
                //->where('patient_type', 'test')
                ->whereBetween('date', [$from, $to])
                ->orderBy('created_at', 'DESC')
                ->get();
        }

        return view('backendview.calculation.calculation', compact('patients', 'testPatients', 'today', 'title', 'iPatients', 'ePatients', 'now'));
    }
}
