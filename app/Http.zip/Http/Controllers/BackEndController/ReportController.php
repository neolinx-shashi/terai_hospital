<?php

namespace App\Http\Controllers\BackEndController;

use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\Billing;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{

    private $patient;
    private $billing;

    public function __construct(Patient $patient, Billing $billing)
    {
        $this->middleware('auth');
        $this->patient = $patient;
        $this->billing = $billing;
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function dailyReport()
    {
        $opdPatient = DB::table('ipatient')
            ->where('refund_status', 'Active')
            ->where('patient_type','=','OPD')
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->sum('doctor_fee_with_tax');
          



        $countPatients = $this->patient
            ->where('refund_status', 'Active')
            ->where('patient_type','=','OPD')
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '=', 'OPD')
            ->orWhere('patient_type', '=', 'renew')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->count();
          
// $projects = DB::table('patients')
//             ->leftjoin('billing_detail', 'patients.id', '=', 'billing_detail.patient_id')
//             ->select('patients.*','billing_detail.*', DB::raw('sum(grand_total) as sum'))
//             ->where('patients.user_id', '=', Auth::user()->id)
//             ->whereDate('patients.created_at', '=', Carbon::now()->toDateString())
//             ->get();

//          return $projects;






        $testTotal = $this->billing
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('status','Active')
            ->sum('grand_total');

        $testPatients = $this->billing
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('status','Active')
            ->get();

       
        $emergencyPatientDatasum = DB::table('ipatient')
            ->where('patient_type', '=', 'Emergency')
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->sum('doctor_fee_with_tax');






        $emergencyRoom = DB::table('ipatient')
            ->where('patient_type', '=', 'Emergency')
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->sum('room_charge');


        $totalAfterEmergency=$emergencyPatientDatasum;

        $emergencyPatientDataTax= $totalAfterEmergency;

        $emergencyPatientData =$emergencyPatientDatasum;



            $emergencyCount = DB::table('ipatient')
            ->where('patient_type', '=', 'Emergency')
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->count();




        $ipatientData = DB::table('ipatient')
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->sum('deposit_amount');



             $ipdCount = DB::table('ipatient')
            ->where('patient_type', '=', 'IPD')
            ->where('user_id', '=', Auth::user()->id)
            ->where('status','=','In Ward')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->count();





        $totalCollection=$opdPatient +$ipatientData + $emergencyPatientData + $testTotal;

        return view('backendview.dashboard.billing.report', compact('countPatients','opdPatient',
            'patients',
            'testTotal',
            'testPatients',
            'emergencyPatientData',
            'ipatientData',
            'emergencyCount',
            'ipdCount',
            'totalCollection'
        ));
    }
}
