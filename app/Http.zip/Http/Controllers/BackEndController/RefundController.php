<?php

namespace App\Http\Controllers\BackEndController;

use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\Billing;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Carbon\Carbon;

class RefundController extends Controller
{
    private $patient;
    private $billing;

    public function __construct(Patient $patient, Billing $billing)
    {
        $this->patient = $patient;
        $this->billing = $billing;
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function refundView()
    {
        $patients = $this->patient
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '=', 'OPD')
            ->orwhere('patient_type','renew')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')
            ->groupBy('patient_code')
            ->paginate(10);




        $testPatients = $this->billing
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')
            ->paginate(10);


        //session(['tabName' => 'opd']);

        return view('backendview.refund.index', compact('patients',
            'testPatients'
        ));
    }

    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function refund($id)
    {
        session()->forget('opd_patient_id');

        $id = (int)$id;
        $patient = $this->patient->find($id);
        $patient->refund_status = ($patient->refund_status == 'Active') ? 'Inactive' : 'Active';
        session(['tabName' => 'opd']);

        $patients = $this->patient
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '!=', '')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')->paginate(10);

        $testPatients = $this->billing
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '=', 'test')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')->paginate(10);

        if ($patient->save()) {
            session()->flash('success', ' Patient fee refunded successfully.');
        } else {
            session()->flash('error', 'Sorry! Could not complete the request.');
        }
        return redirect()->back();
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function testRefund($id)
    {
        $id = (int)$id;
        $patient = $this->billing->findOrFail($id);
        $patient->status = ($patient->status == 'Active') ? 'Inactive' : 'Active';
        session(['tabName' => 'test']);

        $patients = $this->patient
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '!=', '')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')->paginate(10);

        $testPatients = $this->billing
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '=', 'test')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')->paginate(10);

        if ($patient->save()) {
            session()->flash('success', ' Patient fee refunded successfully.');
        } else {
            session()->flash('error', 'Sorry! Could not complete the request.');
        }
        return redirect()->back();
    }

    /**
     * @param $id
     * @return mixed
     */
    public function cancelRefund($id)

    {

        $id = (int)$id;
        $patient = $this->patient->find($id);
        $patient->refund_status = ($patient->refund_status == 'Active') ? 'Inactive' : 'Active';
        session(['tabName' => 'opd']);

        $patients = $this->patient
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '!=', '')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')->paginate(10);

        $testPatients = $this->billing
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '=', 'test')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')->paginate(10);

        if ($patient->save()) {
            session()->flash('success', ' Refund cancelled successfully.');
        } else {
            session()->flash('error', 'Sorry! Could not complete the request.');
        }
        return redirect()->back();
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function cancelTestRefund($id)
    {
        $id = (int)$id;
        $patient = $this->billing->find($id);
        $patient->status = ($patient->status == 'Active') ? 'Inactive' : 'Active';
        session(['tabName' => 'test']);

        $patients = $this->patient
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '!=', '')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')->paginate(10);

        $testPatients = $this->billing
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '=', 'test')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->orderBy('created_at', 'DESC')->paginate(10);

        if ($patient->save()) {
            session()->flash('success', ' Refund cancelled successfully.');
        } else {
            session()->flash('error', 'Sorry! Could not complete the request.');
        }
        return redirect()->back();
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function refundedPatients()
    {
        $patients = $this->patient
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('refund_status', '=', 'Inactive')
            ->orderBy('created_at', 'DESC')
            ->groupBy('patient_code')
            ->paginate(10);

        $testPatients = $this->billing
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('status', '=', 'Inactive')
            ->orderBy('created_at', 'DESC')
            ->paginate(10);

        return view('backendview.refund.refunded_patients', compact('patients',
            'testPatients'));
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function refundPage($id)
    {
        $id = (int)$id;
        $patient = $this->patient->findOrFail($id);
        return view('backendview.refund.refund', compact('patient'));
    }
}