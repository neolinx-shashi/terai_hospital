<?php

namespace App\Http\Controllers\BackEndController;

use App\Http\Controllers\Controller;
use App\Http\Requests;

use App\Models\BloodGroup;
use App\Models\Department;
use App\Models\Doctor;
use App\Models\Nurse;
use App\Models\Patient;
use App\Models\EmergencyPatient;
use App\Models\IPatient;
use App\Models\Nationality;
use App\Models\ConsultingFee;
use App\Models\Billing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\DoctorShift;
use App\Models\ShiftDoctor;
use App\Models\DayName;
use App\Http\Requests\PatientRequest;
use Illuminate\Support\Facades\Session;
use Illuminate\Database\QueryException;
use DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Input;
use App\Models\User;

class DashboardController extends Controller
{
    /**
     * @var User
     */
//    private $user;
    /**
     * @var Feedback
     */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $patient;
    private $nationality;
    private $doctor;
    private $department;
    private $consultingFee;
    private $shift;
    private $shiftDoctor;
    private $dayName;
    private $billing;

    public function __construct(Patient $patient,
                                Nationality $nationality,
                                Doctor $doctor,
                                Department $department,
                                ConsultingFee $consultingFee,
                                DoctorShift $shift,
                                ShiftDoctor $shiftDoctor,
                                DayName $dayName,
                                Billing $billing)
    {
        $this->middleware('auth');
        $this->patient = $patient;
        $this->nationality = $nationality;
        $this->doctor = $doctor;
        $this->department = $department;
        $this->consultingFee = $consultingFee;
        $this->billing = $billing;

        $this->shift = $shift;
        $this->shiftDoctor = $shiftDoctor;
        $this->dayName = $dayName;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $dayData = date("l");

        $doctorListToday = DB::table('day_name')
            ->join('tbl_shift', 'day_name.id', '=', 'tbl_shift.day_id')
            ->join('doctor_shift_relation', 'tbl_shift.id', '=', 'doctor_shift_relation.shift_id')
            ->join('doctors', 'doctor_shift_relation.doctor_id', '=', 'doctors.id')
            ->select('day_name.*', 'doctors.id as doctorId',
                'doctors.first_name',
                'doctors.middle_name',
                'doctors.last_name',
                'doctor_shift_relation.*', 'tbl_shift.*')
            ->groupBy('doctors.id')
            ->where('day_name.name', '=', $dayData)
            ->get();


        $totalShiftListOfDay = DB::table('day_name')
            ->join('tbl_shift', 'day_name.id', '=', 'tbl_shift.day_id')
            ->join('doctor_shift_relation', 'tbl_shift.id', '=', 'doctor_shift_relation.shift_id')
            ->join('doctors', 'doctor_shift_relation.doctor_id', '=', 'doctors.id')
            ->select('day_name.*', 'doctors.id as doctorAllId', 'doctors.first_name as Fname', 'doctor_shift_relation.*', 'tbl_shift.*')
            ->where('day_name.name', '=', $dayData)
            ->get();


        // echo '<pre>';
        // print_r($doctorListToday);
        // echo '</pre>';

        // die();

       $test = DB::table('billing_detail')
            ->where('billing_detail.user_id', '=', Auth::user()->id)
            ->whereDate('billing_detail.created_at', '=', Carbon::now()->toDateString())
            ->where('status','Active')
            ->sum('grand_total');

        $checkUp = DB::table('ipatient')
            ->where('refund_status', '=', 'Active')
            ->where('patient_type','OPD')
            ->where('ipatient.user_id', '=', Auth::user()->id)
            ->whereDate('ipatient.created_at', '=', Carbon::now()->toDateString())
            ->sum('doctor_fee_with_tax');


        $emergencyPatientDatasum = DB::table('ipatient')
            ->where('patient_type', '=', 'Emergency')
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->sum('doctor_fee_with_tax');

              $depositColection = DB::table('ipatient')
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->sum('deposit_amount');



            $emergencyRoom = DB::table('ipatient')
            ->where('patient_type', '=', 'Emergency')
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->sum('room_charge');


        $totalAfterEmergency=$emergencyPatientDatasum+$emergencyRoom;

        $emergencyPatientDataTax= (5 / 100)*$totalAfterEmergency;

        $emergencyPatientData =$emergencyPatientDatasum;


        // $ipatientData = DB::table('ipatient')
        //     ->where('patient_type', '=', 'New')
        //     ->where('user_id', '=', Auth::user()->id)
        //     ->whereDate('created_at', '=', Carbon::now()->toDateString())
        //     ->sum('doctor_fee');

           $ipatientData=  DB::table('discharge_details')
            ->where('user_id', '=', Auth::user()->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->sum('total_after_tax');

           


        $total = $test + $checkUp + $ipatientData+$emergencyPatientData+$depositColection;


      

        $getEmergencyDoctors = DB::table('doctors')
            ->join('departments', 'doctors.department_id', '=', 'departments.id')
            ->join('doctor_shift_relation', 'doctors.id', '=', 'doctor_shift_relation.doctor_id')
            ->join('tbl_shift', 'doctor_shift_relation.shift_id', '=', 'tbl_shift.id')
            ->join('day_name', 'tbl_shift.day_id', '=', 'day_name.id')
            ->select('doctors.id as doctorId', 'tbl_shift.id as shitId', 'tbl_shift.day_id')
            ->where('departments.name', '=', 'emergency')
            ->where('day_name.name', '=', $dayData)
            ->get();

        $getMyPatientsToday = DB::table('ipatient')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('user_id', '=', Auth::user()->id)
            ->where('refund_status','Active')
            ->where('patient_type', '=', 'OPD')
             ->orwhere('patient_type','=','renew')
            ->count();




             $testPatientsTodayOnly = DB::table('ipatient')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '=', 'test')
            ->count();

        $getMyIPDPatientsToday = DB::table('ipatient')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type','IPD')
            ->count();

        $refundedOPDPatientsToday = $this->patient
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('user_id', '=', Auth::user()->id)
            ->where('patient_type', '=', 'OPD')
            ->where('refund_status', '=', 'Inactive')
            ->count();



        $refundedTestPatientsToday = $this->billing
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('user_id', '=', Auth::user()->id)
            ->where('status', '=', 'Inactive')
            ->count();


        $refundedPatientsToday = $refundedOPDPatientsToday + $refundedTestPatientsToday;

        /*$testPatients = DB::table('billing_detail')
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('user_id', '=', Auth::user()->id)
            ->count();

        $getMyPatientsToday = $patients + $testPatients;*/

        $nationality = $this->nationality->all();
        $departments = $this->department->all();
        $doctors = $this->doctor->all();
        $nurses = Nurse::all();
        $consultingFee = $this->consultingFee->all();

        $pieData = DB::table('ipatient')
            ->select('ipatient.gender as gender', DB::raw('count(*) as genderPieData'))
            ->groupBy('gender')
            ->get();

        $genderPieData = array();
        foreach ($pieData as $members) {
            $genderPieData[] = [$members->gender, (int)$members->genderPieData];
        }


        $pieDataAuthUser = DB::table('ipatient')
            ->select('ipatient.gender as gender', DB::raw('count(*) as genderPieDataAuthUser'))
            ->where('user_id', Auth::user()->id)
            ->groupBy('gender')
            ->get();


        $genderPieDataUserOnly = array();
        foreach ($pieDataAuthUser as $members) {
            $genderPieDataUserOnly[] = [$members->gender, (int)$members->genderPieDataAuthUser];
        }


        $totalOnDutyDoctorToday = DB::table('day_name')
            ->join('tbl_shift', 'day_name.id', '=', 'tbl_shift.day_id')
            ->join('doctor_shift_relation', 'tbl_shift.id', '=', 'doctor_shift_relation.shift_id')
            ->join('doctors', 'doctor_shift_relation.doctor_id', '=', 'doctors.id')
            ->select('day_name.*', 'doctors.id as doctorAllId', 'doctors.first_name as Fname', 'doctor_shift_relation.*', 'tbl_shift.*')
            ->where('day_name.name', '=', $dayData)
            ->count();
            

         $department=DB::table('departments')
            ->where('name','Emergency')
            ->first();
            

       $emergencyPatient=DB::table('ipatient')
            ->where('user_id', Auth::user()->id)
            ->where('department_id',$department->id)
            ->whereDate('created_at', '=', Carbon::now()->toDateString())
            ->where('patient_type','Emergency')
            ->count();




        return view('backendview.dashboard.index', compact(
            'nationality',
            'doctors',
            'departments',
            'consultingFee',
            'total',
            'doctorListToday',
            'totalShiftListOfDay',
            'getMyPatientsToday',
            'getEmergencyDoctors',
            'genderPieData',
            'genderPieDataUserOnly',
            'refundedPatientsToday',
            'totalOnDutyDoctorToday',
            'nurses',
            'getMyIPDPatientsToday',
            'emergencyPatient',
            'testPatientsTodayOnly'
        ));


    }


    public function getTodayShiftDoctorList($id)
    {
        $dayData = date("l");
        $totalShiftListOfDay = DB::table('day_name')
            ->join('tbl_shift', 'day_name.id', '=', 'tbl_shift.day_id')
            ->join('doctor_shift_relation', 'tbl_shift.id', '=', 'doctor_shift_relation.shift_id')
            ->join('doctors', 'doctor_shift_relation.doctor_id', '=', 'doctors.id')
            ->select('day_name.*', 'doctors.id as doctorAllId', 'doctors.first_name as Fname', 'doctor_shift_relation.*', 'tbl_shift.*')
            ->where('day_name.name', '=', $dayData)
            ->where('doctors.id', '=', $id)
            ->get();

        echo '<table class="table table-hover table-bordered table-striped">';
        echo '<thead>';

        echo '<strong></strong>';

        echo '<tr>';
        // echo  '<th>S.N</th>';
        echo '<th>Start time</th>';
        echo '<th>End Time</th>';
        echo '<th>Shift Type</th>';
        echo '</tr>';

        echo '</thead>';
        foreach ($totalShiftListOfDay as $file) {
            echo '<tr>';
            $start_time_str = $file->start_time;
            $regular_time_str = date('g:i A', strtotime($start_time_str));

            $end_time_str = $file->end_time;
            $endTime = date('g:i A', strtotime($end_time_str));

            // echo '<td>'.$file->id.'</td>';
            echo '<td>' . $regular_time_str . '</td>';
            echo '<td>' . $endTime . '</td>';
            echo '<td>' . ucfirst($file->shift_type) . '</td>';
            echo '</tr>';

        }
        echo '</table>';


    }


    public function globalSearch()
    {
    $q = Input::get ( 'q' );

    // $opdPatients  = EmergencyPatient::where('first_name','LIKE','%'.$q.'%')
    // ->where('patient_type','!=','test')
    // ->orWhere('middle_name','LIKE','%'.$q.'%')
    // ->orWhere('last_name','LIKE','%'.$q.'%')
    // ->orWhere('phone','LIKE','%'.$q.'%')
    // ->orWhere('patient_code','LIKE','%'.$q.'%')
    // ->orWhere('patient_type','LIKE','%'.$q.'%')
    // ->groupBy('patient_code')
    // ->orderBy('created_at','dsc')
    // ->paginate(10);


  

     $opdPatients = EmergencyPatient::select('ipatient.*')
               ->where('patient_type','!=','test')
                ->where(function ($query)use ($q) {
                $query->orWhere('phone', 'like', '%'.$q.'%')
                      ->orWhere('first_name', 'like', '%'.$q.'%')
                      ->orWhere('last_name', 'like', '%'.$q.'%')
                      ->orWhere('patient_code', 'like', '%'.$q.'%')
                      ->orWhere('patient_type','LIKE','%'.$q.'%')
                      ->orWhere('created_at','like', '%'.$q.'%');
                     
                     
            })
            ->groupBy('patient_code')
             ->orderBy('created_at','dsc')
            ->paginate(10);





    // $emergencyPatients = EmergencyPatient::where('first_name','LIKE','%'.$q.'%')
    // ->orWhere('middle_name','LIKE','%'.$q.'%')
    // ->orWhere('last_name','LIKE','%'.$q.'%')
    // ->orWhere('phone','LIKE','%'.$q.'%')
    // ->orWhere('ipatient_code','LIKE','%'.$q.'%')
    // ->orWhere('patient_type','LIKE','%'.$q.'%')
    // ->get();


      // $emergencyPatients = EmergencyPatient::select('ipatient.*')
      //          ->where('patient_type','=','Emergency')
      //           ->where(function ($query)use ($q) {
      //           $query->orWhere('phone', 'like', '%'.$q.'%')
      //                 ->orWhere('first_name', 'like', '%'.$q.'%')
      //                 ->orWhere('last_name', 'like', '%'.$q.'%')
      //                 ->orWhere('patient_code', 'like', '%'.$q.'%')
      //                 ->orWhere('created_at','like', '%'.$q.'%')
      //                 ->groupBy('ipatient_code')
      //                 ->orderBy('id','DSC');
                     
      //       })
      //       ->paginate(10);




    if(count($opdPatients) > 0)
        return view('backendview.global_search.opdsearch')
        ->withDetails($opdPatients)->withQuery ( $q );


        // elseif (count($ipdPatients) > 0) {
        //       return view('backendview.global_search.ipd_search')
        // ->withDetails($ipdPatients)->withQuery ( $q );

        //     # code...
        // }

        // elseif (count($emergencyPatients) > 0) {
        //       return view('backendview.global_search.emergency_search')
        // ->withDetails($emergencyPatients)->withQuery ( $q );

        //     # code...
        // }

         else return view ('backendview.global_search.emptyresults')
        ->withMessage('No Details found. Try to search again !');

    }

}
