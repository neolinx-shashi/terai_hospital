<?php

namespace App\Http\Controllers\BackEndController;

use App\Models\Department;
use App\Models\IPatient;
use App\Models\Ward;
use App\Models\Room;
use App\Models\Bed;
use App\Models\Nationality;
use App\Models\ConsultingFee;
use App\Models\BloodGroup;
use App\Models\FiscalYear;
use App\Models\Doctor;
use App\Models\DischargeDetail;
use App\Models\DischargeInvoiceItem;
use App\Models\IPatientHistory;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\IPatientRequest;
use App\Http\Requests\GuardianRequest;
use App\http\Requests\IPatientHistoryRequest;
use App\Http\Requests\ReferrerRequest;
use Illuminate\Support\Facades\Session;
use Illuminate\Database\QueryException;
use DB;
use Carbon\Carbon;
use function Sodium\compare;

class IPDController extends Controller
{

    private $iPatient;
    private $nationality;
    private $bloodGroup;
    private $ward;
    private $room;
    private $bed;
    private $patientGuardian;
    private $patientReferrer;
    private $fiscalYear;
    private $dischargeDetail;
    private $iPatientHistory;

    public function __construct(IPatient $iPatient,
                                Nationality $nationality,
                                BloodGroup $bloodGroup,
                                Ward $ward,
                                Room $room,
                                Bed $bed,
                                FiscalYear $fiscalYear,
                                DischargeDetail $dischargeDetail,
                                IPatientHistory $iPatientHistory
    )
    {
        $this->iPatient = $iPatient;
        $this->nationality = $nationality;
        $this->bloodGroup = $bloodGroup;
        $this->ward = $ward;
        $this->room = $room;
        $this->bed = $bed;
        $this->fiscalYear = $fiscalYear;
        $this->dischargeDetail = $dischargeDetail;
        $this->iPatientHistory = $iPatientHistory;
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        $iPatients = $this->iPatient
            ->orderBy('created_at', 'DESC')
            ->where('status', 'In Ward')
            ->where('patient_type', 'IPD')
            ->get();


        return view('backendview.enrollment.ipd.index', compact('iPatients'));
    }


    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create()
    {
        $doctors = Doctor::all();
        $nationality = $this->nationality->all();
        $bloodGroup = $this->bloodGroup->all();
        $wards = $this->ward->all();
        $rooms = $this->room->all();
        $beds = $this->bed->all();

        $patients = $this->iPatient
            ->orderBy('created_at', 'DESC')
            ->where('status', 'In Ward')
            ->where('patient_type', 'IPD')
            ->paginate(7);

        $registeredPatientsToday = $this->iPatient
            ->orderBy('id', 'DESC')
            ->where('patient_type', 'IPD')
            ->whereDate('created_at', '=', Carbon::today()->toDateString())
            ->where('user_id', Auth::user()->id)
            ->where('status', 'In Ward')
            ->paginate(10);

        $patientId = DB::table('ipatient')->max('id');
        $lastInsertedId = $patientId + 1;
        $patientCode = 'TH-' . $lastInsertedId;
        return view('backendview.enrollment.ipd.create', compact('nationality',
            'patients',
            'bloodGroup',
            'wards',
            'rooms',
            'beds',
            'patientCode',
            'registeredPatientsToday',
            'doctors'));
    }


    /**
     * @param IPatientRequest $request
     * @return $this|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(IPatientRequest $request)
    {
        $input = $request->all();
        try {
            if ($request->all()) {
                $user_id = Auth::user()->id;
                $input['user_id'] = $user_id;
                $input['patient_type'] = 'IPD';

                // $patientId='TH-'
                $insertedId = DB::table('ipatient')->max('id');
                $lastInsertedId = $insertedId + 1;
                $input['patient_code'] = 'TH-' . $lastInsertedId;

                $fiscalYear = $this->fiscalYear
                    ->where('current_fiscal_year', 'Y')
                    ->first();

                $input['fiscal_year_id'] = $fiscalYear->id;

                $iPatient = iPatient::create($input);
                $ipatient_id = $iPatient->id;
                session()->put('ipatient_id', $ipatient_id);

                $bed = $this->bed->findOrFail($request->bed_id);
                $bed->availability = 'Unavailable';
                $bed->save();
                session()->flash('success', 'Patient created Successfully!');
                return redirect('ip-enrollment/patients/create')
                    ->withInput();
            } else {
                return redirect()
                    ->back();
            }
        } catch
        (Exception $e) {
            session()->flash('error', 'Sorry Unable to handle the request');
        }
    }


    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show($id)
    {
        $id = (int)$id;

        $patient = $this->iPatient->findOrFail($id);
        return view('backendview.enrollment.ipd.show', compact('patient'));
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit($id)
    {
        $id = (int)$id;
        $doctors = Doctor::all();
        $editPatients = $this->iPatient->findOrFail($id);
        $nationality = $this->nationality->all();
        $bloodGroup = $this->bloodGroup->all();
        $wards = $this->ward->all();
        $rooms = $this->room->all();
        $beds = $this->bed->all();
        $patients = $this->iPatient
            ->orderBy('created_at', 'DESC')
            ->where('status', 'In Ward')
            ->paginate(7);
        return view('backendview.enrollment.ipd.edit', compact('editPatients',
            'bloodGroup',
            'nationality',
            'patients',
            'wards',
            'rooms',
            'doctors',
            'beds'));
    }

    /**
     * @param PatientRequest $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $id = (int)$id;
        if ($request->all()) {
            $data = $this->iPatient->find($id);

            if ($data->bed_id != $request->bed_id) {
                $oldBed = $this->bed->findOrFail($data->bed_id);
                $oldBed->availability = 'Available';
                $oldBed->update();

                $newBed = $this->bed->findOrFail($request->bed_id);
                $newBed->availability = 'Unavailable';
                $newBed->update();
            }

            if ($data) {
                $data->fill($request->all())->save();
            }

            session()->flash('success', 'Patient updated Successfully');
            return redirect('ip-enrollment/patients');
        } else {
            session()->flash('error', 'Sorry unable to handle the request');
            return redirect()
                ->back()
                ->withInput();
        }
    }


    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function editGuardian($id)
    {
        $id = (int)$id;
        $editPatients = $this->iPatient->findOrFail($id);
        return view('backendview.enrollment.ipd.guardian.guardian', compact('editPatients',
            'nationality'));
    }

    /**
     * @param PatientRequest $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function addGuardian(GuardianRequest $request, $id)
    {
        $id = (int)$id;
        if ($request->all()) {
            $data = $this->iPatient->find($id);
            if ($data) {
                $data->fill($request->all())->save();
                session()->flash('success', 'Patient updated Successfully');
                return redirect('ip-enrollment/patients');
            }
        } else {
            return redirect()
                ->back()
                ->withInput();
        }
        session()->flash('error', 'Sorry unable to handle the request');
        return redirect('ip-enrollment/patients');
    }


    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function editReferrer($id)
    {
        $id = (int)$id;
        $editPatients = $this->iPatient->findOrFail($id);
        return view('backendview.enrollment.ipd.referrer.referrer', compact('editPatients',
            'nationality'));
    }

    /**
     * @param PatientRequest $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function addReferrer(ReferrerRequest $request, $id)
    {
        $id = (int)$id;
        if ($request->all()) {
            $data = $this->iPatient->find($id);
            if ($data) {
                $data->fill($request->all())->save();
                session()->flash('success', 'Patient updated Successfully');
                return redirect('ip-enrollment/patients/47/edit');
            }
        } else {
            return redirect()
                ->back()
                ->withInput();
        }
        session()->flash('error', 'Sorry unable to handle the request');
        return redirect('ip-enrollment/patients/47/edit/tabs-3');
    }

    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        try {
            $id = (int)$id;
            $data = $this->iPatient->find($id);
            if ($data) {
                $data->delete();
                session()->flash('success', 'Patient Deleted Successfully');
            }
            return redirect()->back();
            session()->flash('error', 'Sorry unable to delete patient');
            return redirect()->back();

        } catch (QueryException $e) {
            session()->flash('foreignerror', 'Sorry unable to handle the request');
            return redirect('ip-enrollment');
        }
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function Discharge()
    {
        $patients = $this->iPatient
            ->where('patient_type', '=', 'IPD')
            ->orderBy('created_at', 'DESC')
            ->get();
        return view('backendview.enrollment.ipd.discharge', compact('patients'));
    }

    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function dischargePatient($id)
    {
        $id = (int)$id;
        $dischargePatients = $this->iPatient->findOrFail($id);
        $dischargePatients->status = 'Discharged';
        $dischargePatients->discharged_at = Carbon::now()->toDateTimeString();
        $dischargePatients->update();

        $bed = $this->bed->findOrFail($dischargePatients->bed_id);
        $bed->availability = 'Available';
        $bed->update();
        session()->flash('success', 'Patient discharged Successfully');

        return redirect('ip-enrollment/ipatient/' . $dischargePatients->id . '/print-invoice');
    }

    /**
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function cancelDischarge($id)
    {
        $id = (int)$id;
        $patient = $this->iPatient->findOrFail($id);

        if ($patient->isOfBed->availability == 'Available') {
            $patient->status = 'In Ward';
            $patient->discharged_at = '';
            $patient->update();

            $bed = $this->bed->findOrFail($patient->bed_id);
            $bed->availability = 'Unavailable';
            $bed->update();
            session()->flash('success', 'Patient discharge cancelled Successfully');
        } else {
            session()->flash('foreignerror', 'Sorry, the bed assigned to the patient is unavailable!');
        }

        return redirect('ip-enrollment/discharge-patient');
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function printInvoice($id)
    {
        $id = (int)$id;

        $patient = $this->iPatient->findOrFail($id);

        $test_category = Category::where('level', 1)->orderBy('title', 'asc')->get();

        $now = Carbon::now();
        $admitted_at = $patient->created_at;
        $daysInHospital = $admitted_at->diffInDays($now) + 1;

        $roomRate = $patient->isOfRoom->room_rate;
        $roomCharge = $roomRate * $daysInHospital;

        if (count($patient->hasHistory)) {
            $doctorVisits = $patient->hasHistory;

            $doctorVisitCharge = 0;
            foreach ($doctorVisits as $doctorVisit) {
                $doctorVisitCharge += $doctorVisit->doctor_fee;
            }

            $subTotal = $roomCharge + $doctorVisitCharge;
        } else {
            $subTotal = $roomCharge;
            $doctorVisitCharge = '';
        }

        $hst = 5 / 100 * $subTotal;

        $deposit = $patient->deposit_amount;

        /*if ($total > $deposit) {
            $due = $total - $deposit;
            $return = 0;
        } else {
            $return = $deposit - $total;
            $due = 0;
        }*/


        if ($patient) {
            return view('backendview.enrollment.ipd.invoice', compact(
                'patient',
                'roomRate',
                'roomCharge',
                'daysInHospital',
                'doctorVisits',
                'doctorVisitCharge',
                'subTotal',
                'hst',
                'deposit',
                'test_category'
            ));
        } else
            abort(404);

    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function printAdmitInvoice($id)
    {
        session()->forget('ipatient_id');
        $id = (int)$id;
        $patient = $this->iPatient->findOrFail($id);
        $doctor = Doctor::findOrFail($patient->doctor_id);
        $ward = $patient->isOfWard->ward_name;
        $room = $patient->isOfRoom->room_name;
        $bed = $patient->isOfBed->bed_name;
        $roomCharge = $patient->isOfRoom->room_rate;
        $doctorCharge = $doctor->normal_fee;
        $subTotal = $roomCharge + $doctorCharge;
        $hst = 5 / 100 * $subTotal;
        $total = $subTotal + $hst;

        /*$now = Carbon::now();
        $admitted_at = $patient->created_at;

        $daysInHospital = $admitted_at->diffInDays($now);

        $roomRate = $patient->isOfRoom->room_rate;
        $roomCharge = $roomRate * $daysInHospital;

        if (count($patient->hasHistory)) {
            $doctorVisits = $patient->hasHistory;

            $doctorVisitCharge = 0;
            foreach ($doctorVisits as $doctorVisit) {
                $doctorVisitCharge += $doctorVisit->doctor_fee;
            }

            $subTotal = $roomCharge + $doctorVisitCharge;
        } else {
            $subTotal = $roomCharge;
        }

        $hst = 5 / 100 * $subTotal;*/

        $deposit = $patient->deposit_amount;

        /*if ($total > $deposit) {
            $due = $total - $deposit;
            $return = 0;
        } else {
            $return = $deposit - $total;
            $due = 0;
        }*/

        if ($patient) {
            return view('backendview.enrollment.ipd.admit_invoice', compact(
                'patient',
                'deposit',
                'ward',
                'room',
                'bed',
                'doctor',
                'roomCharge',
                'doctorCharge',
                'subTotal',
                'hst',
                'total'
            ));
        } else
            abort(404);
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function DoctorDetails()
    {
        $iPatients = $this->iPatient->all();
        return view('backendview.enrollment.ipd.patientHistory.index', compact('iPatients'));
    }

    /**
     * @param Request $request
     */
    public function insertDischargeInvoiceDetail(Request $request)
    {
        $input = $request->all();

        $discharge_detail = array(
            'user_id' => Auth::user()->id,
            'ipatient_id' => $input['ipatient_id'],
            'room_charge' => $input['room_charge'],
            'doctor_charge' => $input['doctor_charge'],
            'discount' => $input['discount'],
            'subtotal_after_discount' => $input['subtotal_after_discount'],
            'total_after_tax' => $input['total_after_tax'],
            'hst' => $input['hst'],
        );

        //return $discharge_detail;

        $discharge = $this->dischargeDetail->create($discharge_detail);

        if ($input['test_id']) {
            $test_arr = explode('-', $input['test_id']);
            $price_arr = explode('-', $input['test_price']);
            $qty_arr = explode('-', $input['test_quantity']);
            $count_test = count($test_arr);
            $did = $discharge->id;

            for ($i = 0; $i < $count_test; $i++) {
                $discharge_item_detail = array(
                    'discharge_id' => $did,
                    'test_id' => $test_arr[$i],
                    'test_price' => $price_arr[$i],
                    'test_quantity' => $qty_arr[$i]
                );
                //dd($discharge_item_detail);

                DischargeInvoiceItem::create($discharge_item_detail);
            }
        }
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function insertDoctorDetails($id)
    {
        $id = (int)$id;
        $patient = $this->iPatient->findOrFail($id);
        $doctors = Doctor::all();

        return view('backendview.enrollment.ipd.insert_doctor_detail', compact('patient', 'doctors'));
    }

    /**
     * @param $id
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function getDoctorDetails($id)
    {
        $id = (int)$id;
        $patient = $this->iPatient->findOrFail($id);
        if ($patient->hasHistory) {
            $items = $patient->hasHistory;

            foreach ($items as $item) {
                $doctor = Doctor::findOrFail($item->doctor_id);
                $doctor_name = $doctor->first_name . ' ' . $doctor->middle_name . ' ' . $doctor->last_name;
                $item->doctor_name = $doctor_name;
            }
            //dd($items);


            return response()->json($items);
        } else {
            session()->flash('error', 'Sorry Unable to handle the request');
            return redirect()->back();
        }
    }

    /**
     * @param IPatientHistoryRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function storeDoctorDetails(Request $request)
    {
        $input = $request->all();
        //dd($input);
        $create = $this->iPatientHistory->create($input);

        return response()->json($create);
    }

    /**
     * @param $id
     * @param $pid
     * @return \Illuminate\Http\JsonResponse
     */
    public function deleteDoctorDetails($id, $pid)
    {
        $pid = (int)$pid;
        $this->iPatientHistory->findOrFail($pid)->delete();
        return response()->json(['done']);
    }

    /**
     * @param IPatientHistoryRequest $request
     * @param $id
     * @param $pid
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateDoctorDetails(Request $request, $id, $pid)
    {
        $pid = (int)$pid;
        $edit = $this->iPatientHistory->findOrFail($pid)->update($request->all());
        return response()->json($edit);
        $id = (int)$id;
        $this->iPatientHistory->findOrFail($id)->delete();
        return response()->json(['done']);
    }

    public function patientHistory()
    {
        return view('backendview.enrollment.ipd.patientHistory.index');
    }

    public function generateHistory()
    {
        //display patientHistory
    }

    public function patientReport()
    {

        return view('backendview.enrollment.ipd.patientReport.index');
    }

    public function generateReport()
    {
        //display patientHistory
    }
}
