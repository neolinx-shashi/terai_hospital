<?php

namespace App\Http\Controllers\Appointment;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\DoctorShift;
use App\Models\ShiftDoctor;
use Illuminate\Support\Facades\DB;

class AppointmentController extends Controller
{
    public function __construct() {

    }

    public function index() {
        $today = date("Y-m-d");
        $day = date("w");
        //$doctors = Doctor::orderBy('first_name', 'asc')->get();
        $doctors = Doctor::leftJoin('departments', 'doctors.department_id', '=', 'departments.id')
            ->orderBy('doctors.first_name', 'asc')
            ->get();

        foreach ($doctors as $key => $list) {
            $schedule = DB::table('doctor_shift_relation')
                ->leftJoin('tbl_shift', 'doctor_shift_relation.shift_id', '=', 'tbl_shift.id')
                ->leftJoin('doctors', 'doctor_shift_relation.doctor_id', '=', 'doctors.id')
                ->where('doctors.id', $list->id)
                ->get();

            $doctors[$key]['schedule'] = $schedule;
        }

        return view('appointment.doctorlist', compact('doctors'));
    }

    public function reserve($doc_id, $shift_id) {
        return view('appointment.appointment_view', compact('doc_id', 'shift_id'));
    }

    public function operatereserve(Request $request) {
        $input = $request->all();

        $data = array(
            'patient_contact' => $input['patient_contact'],
            'patient_name' => $input['patient_name'],
            'res_date' => $input['appointment_date'],
            'res_doc_id' => $input['doc_id'],
            'res_shift_id' => $input['shift_id']
        );

        $insert = Appointment::create($data);

        if ($insert) {
            $message = 'Data Saved Successfully.';
        } else {
            $message = 'Data Saving Failed. Try Again.';
        }
        $request->session()->flash('message', $message);

        return redirect('appointment');
    }

    public function searchDoctor(Request $request) {
        $keyword = $request->get('keyword');

        /*
        $doctors = Doctor::leftJoin('departments', 'doctors.department_id', '=', 'departments.id')
                    ->orderBy('doctors.first_name', 'asc')
                    ->get();
        */

        $doctors = Doctor::leftJoin('departments', 'doctors.department_id', '=', 'departments.id')
            ->where('doctors.first_name', 'like', '%'.$keyword.'%')
            ->orWhere('doctors.last_name', 'like', '%'.$keyword.'%')
            ->orWhere('departments.name', 'like', '%'.$keyword."%")
            ->orderBy('doctors.first_name', 'asc')
            ->get();

        foreach ($doctors as $key => $list) {
            $schedule = DB::table('doctor_shift_relation')
                ->leftJoin('tbl_shift', 'doctor_shift_relation.shift_id', '=', 'tbl_shift.id')
                ->leftJoin('doctors', 'doctor_shift_relation.doctor_id', '=', 'doctors.id')
                ->where('doctors.id', $list->id)
                ->get();

            $doctors[$key]['schedule'] = $schedule;
        }

        return view('appointment.doctorlist', compact('doctors', 'keyword'));
    }

}