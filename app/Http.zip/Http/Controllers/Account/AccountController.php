<?php

namespace App\Http\Controllers\Account;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Billing;
use App\Models\Doctor;
use App\Models\Patient;
use App\Models\TestDetail;
use DB;

class AccountController extends Controller
{

    public function __construct()
    {
        $this->today = date("Y-m-d");
    }

    public function index()
    {

    }

    public function billingReport()
    {
        $from = $this->today;
        $to = $this->today;
        $today = $this->today;
        $title = 'Daily Report';
        //$report = Billing::whereBetween('date', [$from, $to])->get();
        $report = DB::table('billing_detail')
            ->leftJoin('patients', 'billing_detail.patient_id', '=', 'patients.id')
            ->whereBetween('billing_detail.date', [$from, $to])
            ->get();

        $test_report = DB::table('test_detail')
            ->leftJoin('categories', 'test_detail.test_id', '=', 'categories.id')
            ->leftJoin('billing_detail', 'test_detail.bid', '=', 'billing_detail.bid')
            ->whereBetween('billing_detail.date', [$from, $to])
            ->get();

        $doctor_report = DB::table('billing_detail')
            ->leftJoin('patients', 'billing_detail.patient_id', '=', 'patients.id')
            ->leftJoin('doctors', 'patients.doctor_id', '=', 'doctors.id')
            ->selectRaw('sum(patients.doctor_fee) as total, doctors.first_name, doctors.middle_name, doctors.last_name')
            ->whereBetween('billing_detail.date', [$from, $to])
            ->groupBy('doctors.id')
            ->orderBy('doctors.first_name', 'asc')
            ->get();
        //dd($doctor_report);

        return view('account.billing_report', compact('report', 'test_report', 'doctor_report', 'today'));
    }

    public function monthlyReport()
    {
        $month = date("m");
        $today = $this->today;
        $title = 'Monthly Report';

        $report = DB::table('billing_detail')
            ->leftJoin('patients', 'billing_detail.patient_id', '=', 'patients.id')
            ->where('billing_detail.date', 'like', '%-' . $month . '-%')
            ->get();

        $test_report = DB::table('test_detail')
            ->leftJoin('categories', 'test_detail.test_id', '=', 'categories.id')
            ->leftJoin('billing_detail', 'test_detail.bid', '=', 'billing_detail.bid')
            ->where('billing_detail.date', 'like', '%-' . $month . '-%')
            ->get();

        $doctor_report = DB::table('billing_detail')
            ->leftJoin('patients', 'billing_detail.patient_id', '=', 'patients.id')
            ->leftJoin('doctors', 'patients.doctor_id', '=', 'doctors.id')
            ->selectRaw('sum(patients.doctor_fee) as total, doctors.first_name, doctors.middle_name, doctors.last_name')
            ->where('billing_detail.date', 'like', '%-' . $month . '-%')
            ->groupBy('doctors.id')
            ->orderBy('doctors.first_name', 'asc')
            ->get();


        return view('account.billing_report', compact('report', 'test_report', 'doctor_report', 'today'));
    }

    public function yearlyReport()
    {
        $year = date("Y");
        $today = $this->today;
        $title = 'Yearly Report';

        $report = DB::table('billing_detail')->leftJoin('patients', 'billing_detail.patient_id', '=', 'patients.id')->where('billing_detail.date', 'like', '%' . $year . '-%')->get();

        $test_report = DB::table('test_detail')
            ->leftJoin('categories', 'test_detail.test_id', '=', 'categories.id')
            ->leftJoin('billing_detail', 'test_detail.bid', '=', 'billing_detail.bid')
            ->where('billing_detail.date', 'like', '%' . $year . '-%')
            ->get();

        $doctor_report = DB::table('billing_detail')
            ->leftJoin('patients', 'billing_detail.patient_id', '=', 'patients.id')
            ->leftJoin('doctors', 'patients.doctor_id', '=', 'doctors.id')
            ->selectRaw('sum(patients.doctor_fee) as total, doctors.first_name, doctors.middle_name, doctors.last_name')
            ->where('billing_detail.date', 'like', '%' . $year . '-%')
            ->groupBy('doctors.id')
            ->orderBy('doctors.first_name', 'asc')
            ->get();


        return view('account.billing_report', compact('report', 'test_report', 'doctor_report', 'today'));
    }

    public function dateReport(Request $request)
    {
        $input = $request->all();
        $from = $input['date_from'];
        $to = $input['date_to'];
        $today = $this->today;
        $title = 'Report';
        //$report = Billing::whereBetween('date', [$from, $to])->get();
        $report = DB::table('billing_detail')
            ->leftJoin('patients', 'billing_detail.patient_id', '=', 'patients.id')
            ->whereBetween('billing_detail.date', [$from, $to])
            ->get();

        $test_report = DB::table('test_detail')
            ->leftJoin('categories', 'test_detail.test_id', '=', 'categories.id')
            ->leftJoin('billing_detail', 'test_detail.bid', '=', 'billing_detail.bid')
            ->whereBetween('billing_detail.date', [$from, $to])
            ->get();

        $doctor_report = DB::table('billing_detail')
            ->leftJoin('patients', 'billing_detail.patient_id', '=', 'patients.id')
            ->leftJoin('doctors', 'patients.doctor_id', '=', 'doctors.id')
            ->selectRaw('sum(patients.doctor_fee) as total, doctors.first_name, doctors.middle_name, doctors.last_name')
            ->whereBetween('billing_detail.date', [$from, $to])
            ->groupBy('doctors.id')
            ->orderBy('doctors.first_name', 'asc')
            ->get();

        return view('account.billing_report', compact('report', 'test_report', 'doctor_report', 'today'));
    }

    public function doctorReport(Request $request)
    {
        $doctors = Doctor::orderBy('first_name', 'asc')->get();
        //var_dump($doctors);die;
        foreach ($doctors as $key => $list) {
            $patients = Patient::where('doctor_id', $list->id)
                ->select('id', 'first_name', 'middle_name', 'last_name', 'gender', 'doctor_fee','doctor_fee_with_tax', 'appointment')
                ->get();
            $doctors[$key]['patients'] = $patients;

            /*
            $tests = DB::table('billing_detail')
                    ->leftJoin('patients', 'billing_detail.patient_id', '=', 'patients.id')
                    ->rightJoin('test_detail', 'billing_detail.bid', '=', 'test_detail.bid')
                    ->where('billing_detail.doctor_id', $list->id)
                    ->orderBy('patients.first_name')
                    ->get();
             * 
             */
            $tests = DB::table('test_detail')
                ->leftJoin('billing_detail', 'test_detail.bid', '=', 'billing_detail.bid')
                ->leftJoin('categories', 'test_detail.test_id', '=', 'categories.id')
                ->where('billing_detail.doctor_id', $list->id)
                ->get();

            $doctors[$key]['tests'] = $tests;
        }
        //var_dump($doctors);die;

        return view('account.doctor_report', compact('doctors'));
    }

}
